#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
    if (argc != 2)
    {
        printf("Usage: ./revocer file");
        return 1;
    }
    
    FILE *file = fopen(argv[1], "r");    
    FILE *img = NULL;
    unsigned char buffer[512];
    int counter = 0;
    char filename[8];
    int inImage = 0;
    
   /* if (file == NULL)
    {
    fprintf(stderr, "Could not open card.raw\n ");
    return 1;
    } */

    while (fread(buffer, 512, 1, file) == 1)
    {
        if (buffer[0] == 0xff && buffer[1] == 0xd8 && buffer[2] == 0xff && (buffer[3] & 0xf0) == 0xe0)
        {
            if (inImage == 1)
            {
                fclose(img);
                inImage = 0;
            }
            inImage = 1;
            sprintf(filename, "%03i.jpg", counter);
            img = fopen(filename, "w");
            counter++;
        }
        if (inImage == 1)
        {
            fwrite(&buffer, 512, 1, img);
        }
    }
    fclose(file);
    fclose(img);
    return 0;
}
