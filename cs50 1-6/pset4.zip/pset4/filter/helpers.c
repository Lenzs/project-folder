#include "helpers.h"
#include "math.h"

// Convert image to grayscale
void grayscale(int height, int width, RGBTRIPLE image[height][width])
{
    for (int i = 0; i < height; i ++)
    {
        for (int j = 0; j < width; j++)
        {
            int red = image[i][j].rgbtRed;
            int green = image[i][j].rgbtGreen;
            int blue = image[i][j].rgbtBlue;
            int average;
            int isGray = 0;
            

            average = round((red + green + blue) / 3.0);
            image[i][j].rgbtRed = average;
            image[i][j].rgbtBlue = average;
            image[i][j].rgbtGreen = average;
        }
    }
    return;
}

// Reflect image horizontally
void reflect(int height, int width, RGBTRIPLE image[height][width])
{
    RGBTRIPLE temp[height][width];
    
    for (int i = 0; i < height; i ++)
    {
        int index = 1;
        
        for (int j = 0; j < width; j++, index++)
        {
            temp[i][j] = image[i][width - index];
        }
    }
    
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
           image[i][j] = temp[i][j];
        }
    }
    return;
}

// Blur image
void blur(int height, int width, RGBTRIPLE image[height][width])
{
    RGBTRIPLE temp[height][width];
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            int count = 0;
            float red = 0;
            float green = 0;
            float blue = 0;
            int yCoords[] = {i - 1, i, i + 1};
            int xCoords[] = {j - 1, j, j + 1};
            int repNum = 3;
            
            for (int k = 0; k < repNum; k++)
            {
                for (int m = 0; m < repNum; m++)
                {
                    if (yCoords[k] >= 0 && yCoords[k] < height && xCoords[m] >= 0 && xCoords[m] < width)
                    {
                        RGBTRIPLE current = image[yCoords[k]][xCoords[m]];
                        red = red + current.rgbtRed ;
                        green = green + current.rgbtGreen;
                        blue = blue + current.rgbtBlue;
                        count++;
                    }
                }
            }
            temp[i][j].rgbtRed = round(red / count);
            temp[i][j].rgbtGreen = round(green / count);
            temp[i][j].rgbtBlue = round(blue / count);
        }
    }
    for (int y = 0; y < height; y++)
    {
        for (int x = 0; x < width; x++)
        {
            image[y][x] = temp[y][x];
        }
    }
    return;
}

// Detect edges
void edges(int height, int width, RGBTRIPLE image[height][width])
{
    int Gx[3][3] = {{-1, 0, 1}, {-2, 0, 2}, {-1, 0, 1}};
    int Gy[3][3] = {{-1, -2, -1}, {0, 0 ,0}, {1, 2, 1}};
    RGBTRIPLE temp[height][width];
    
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            int yCoords[] = {i - 1, i, i + 1};
            int xCoords[] = {j - 1, j, j + 1};
            
            int redGx = 0;
            int greenGx = 0;
            int blueGx = 0;
            
            int redGy = 0;
            int greenGy = 0;
            int blueGy = 0;
            
            float red = 0;
            float green = 0;
            float blue = 0;
            
            for (int k = 0; k < 3; k++)
            {
                for (int m = 0; m < 3; m++)
                {
                    if (yCoords[k] >= 0 && yCoords[k] < height && xCoords[m] >= 0 && xCoords[m] < width)
                    {
                        RGBTRIPLE current = image[yCoords[k]][xCoords[m]];
                        
                        redGx = redGx + Gx[k][m] * current.rgbtRed ;
                        greenGx = greenGx + Gx[k][m] * current.rgbtGreen;
                        blueGx = blueGx + Gx[k][m] * current.rgbtBlue;
                        
                        redGy = redGy + Gy[k][m] * current.rgbtRed ;
                        greenGy = greenGy + Gy[k][m] * current.rgbtGreen;
                        blueGy = blueGy + Gy[k][m] * current.rgbtBlue;
                    }
                }
            }
            red = sqrt(redGx^2 + redGy^2);
            green = round(sqrt(greenGx^2 + greenGy^2);
            blue = round(sqrt(blueGx^2 + blueGy^2);
            
            if (red > 255)
            {
                red = 255;
                temp[i][j].rgbtRed = red;
            }
            else
            {
                temp[i][j].rgbtRed = red;
            }
            if (green > 255)
            {
                green = 255;
                temp[i][j].rgbtGreen = green;
            }
            else
            {
                temp[i][j].rgbtGreen = green;
            }
            if (blue > 255)
            {
                blue = 255;
                temp[i][j].rgbtBlue = blue;
            }
            else
            {
                temp[i][j].rgbtBlue = blue;
            }
        }
    }
    for (int y = 0; y < height; y++)
    {
        for (int x = 0; x < width; x++)
        {
            image[y][x] = temp[y][x];
        }
    }
    return;
}

            