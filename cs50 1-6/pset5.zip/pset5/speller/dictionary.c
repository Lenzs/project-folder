// Implements a dictionary's functionality
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <strings.h>
#include <ctype.h>
#include "dictionary.h"

// Represents a node in a hash table
typedef struct node
{
    char word[LENGTH + 1];
    struct node *next;
}
node;

// Number of buckets in hash table
const unsigned int N = 1;
const int HASHTABLE_SIZE = 100000;
int dictionary_size = 0;
// Hash table
node *table[N];
node *hashtable[HASHTABLE_SIZE];

// Returns true if word is in dictionary else false
bool check(const char *word)
{
    int l = strlen(word);
    char temp[LENGTH + 1];
    
    for (int i = 0; i < l; i++)
    {
        temp[i] = tolower(word[i]);
    }
    
    temp[l] = '\0';
    int hashIndex = hash(temp);
    node *pointer = hashtable[hashIndex];

    while (pointer != NULL)
    {
        if (strcasecmp(pointer->word, word) == 0)
        {
            return true;
        }
        else
        {
            pointer = pointer->next;
        }
    }
    return false;
}

// Hashes word to a number
unsigned int hash(const char *word)
{
    unsigned int hash = 0;
    for (int i = 0, n = strlen(word); i < n; i++)
    {
        hash = (hash << 2) ^ word[i];
    }
    return hash % HASHTABLE_SIZE;
}

// Loads dictionary into memory, returning true if successful else false
bool load(const char *dictionary)
{
    FILE *file = fopen(dictionary, "r");
    char word[LENGTH + 1];
    int index;
    
    if (file == NULL)
    {
        printf("Could not open file.");
        return false;
    }
    
    while (fscanf(file, "%s", word) != EOF)
    {
        node *n = malloc(sizeof(node));
        
        if (n == NULL)
        {
            printf("Out of memory.");
            return false;
        }
        
        strcpy(n->word, word);
        n->next = NULL;
        
        index = hash(word);
        
        if (hashtable[index] == NULL)
        {
            hashtable[index] = n;
        }
        else
        {
            n->next = hashtable[index];
            hashtable[index] = n;
        }
        dictionary_size = dictionary_size + 1;
    }
    fclose(file);
    return true;
}

// Returns number of words in dictionary if loaded else 0 if not yet loaded
unsigned int size(void)
{
    return dictionary_size;
}

// Unloads dictionary from memory, returning true if successful else false
bool unload(void)
{
    for (int i = 0; i < HASHTABLE_SIZE; i++)
    {
        node *pointer = NULL;
        node *temp = NULL;
        if (hashtable[i] != NULL)
        {    
            temp = hashtable[i];
            while (hashtable[i]->next != NULL)
            {
                pointer = temp->next;
                free(pointer);
                free(hashtable[i]);
            }
        }
        free(temp);
    }
    return true;
}
