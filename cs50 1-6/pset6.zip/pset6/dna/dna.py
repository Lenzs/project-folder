from sys import argv
import csv 
import re

def main():
    if len(argv) != 3:
        print("Usage: python dna.py data.csv sequence.txt")
        quit()
        
    with open(argv[1]) as database:
        reader = csv.DictReader(database)
        repeatsList = list(reader)
    with open(argv[2]) as sequences:
        text = sequences.readline().rstrip("\n")
        
    checklistSmall = ["AGATC", "AATG", "TATC"]
    repeatsSmall = []
    for index in range(len(checklistSmall)):
        repeatsSmall.append(index) 
        repeatsSmall[index] = text.count(checklistSmall[index])
        
    checklist = ["AGATC", "TTTTTTCT", "AATG", "TCTAG", "GATA", "TATC", "GAAA", "TCTG"]
    repeats = []
    for index in range(len(checklist)):
        checker = checklist[index]
        repeats.append(index)
        for x in range(int(int(len(text)) / int(len(checklist[index])))):
            if text.count(checker) != 0:
                maxRepeat = x + 1
                checker = str(checker + checklist[index])
            else:
                checker = str(checker + checklist[index])
            x += 1
        repeats[index] = maxRepeat
        
    if argv[1] == "databases/small.csv":
        matchCount = 0
        for person in range(3):
            found = False
            for index in range(3):
                if repeatsList[person][checklistSmall[index]] == str(repeatsSmall[index]):
                    matchCount = matchCount + 1
                if matchCount == 3:
                    name = repeatsList[person]["name"]
                    matchCount = 0
                    found = True
                elif index == 2:
                    name = "No match"
                    matchCount = 0
            if found:
                break
        print(name)
    else:
        matchCount = 0
        for person in range(22):
            found = False
            for index in range(8):
                if repeatsList[person][checklist[index]] == str(repeats[index]):
                    matchCount = matchCount + 1
                    #print(matchCount)
                if matchCount == 8:
                    name = repeatsList[person]["name"]
                    matchCount = 0
                    found = True
                elif index == 7:
                    name = "No match"
                    matchCount = 0
            if found:
                break
        print(name)
                    
main()

    
    





    

