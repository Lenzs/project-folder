from cs50 import get_int

def main():
    card = cardLength = 0
    isValid = False
    card = get_int(" Number: ")
    cardLength = len(str(card))
    isValid = checkValidity(card)
    if(isValid):
        if cardLength == 16 and card >= 51e14 and card < 56e14:
            print("MASTERCARD")
        elif cardLength == 13 and card >= 4e12 and card < 5e12 or cardLength == 16 and card >= 4e15 and card < 5e15:
            print("VISA")
        else:
            print("INVALID")
    elif checkAMEX and card >= 37e13 and card < 38e13 or card >= 34e13 and card < 35e13:
        print("AMEX")
    else:
        print("INVALID")

def checkValidity(n):
    num1 = num2 = sum1 = sum2 = sumFinal = 0
    for n in range(0, len(str(n))):
        i = 0
        if i%2 == 0:
            num1 = n%10
            sum1 = sum1 + num1
        else:
            num2 = n%10
            num2 = num2*2
            sum2 = sum2 + num2/10 + num2%10
        sumFinal = sum1 + sum2
        n = n/10
        i = i + 1
    if sumFinal%10==0:
        return(True)
    else:
        return(False)
        
def checkAMEX(n):
    num1 = num2 = sum1 = sum2 = sumFinal = 0
    for n in range(1, len(str(n)) + 1):
        i = 0
        if i%2==0:
            num1 = n%10
            sum1 = sum1 + num1
        else:
            num2 = n%10
            num2 = num2*2
            sum2 = sum2 + num2/10 + num2%10
        sumFinal = sum1 + sum2
        n = n/10
        i = i + 1
    if sumFinal%10==0:
        return(True)
    else:
        return(False)
        
main()