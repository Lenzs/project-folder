from cs50 import get_string

def main():
    averageL = averageS = index = 0
    words = 1
    text = get_string("Text: ")
    length = len(text)
    sentence = text
    
    for i in range(length):
        if ord(text[i]) == 32:
            words = words + 1
            
    averageL = getL(sentence, length, words)
    print(str(words) + " Word(s)")
    averageS = getS(sentence, length, words)
    
    index = (0.0588 * averageL - 0.296 * averageS - 15.8);
    if index < 16.5 and index >= 0.5:
        index = round(index)
        print("Grade " + str(index))
    elif (index > 16.5):
        index = round(index)
        print("Grade 16+")
    elif (index < 0.5):
        print("Before Grade 1")

def getL(sentence, length, words):
    letters = 0
    multiplier = 100 / words
    for i in range(length):
        if ord(sentence[i]) < 123 and ord(sentence[i]) > 96 or ord(sentence[i]) < 91 and ord(sentence[i]) > 64:
            letters += 1
    print(str(letters) + " Letter(s)")
    letters = letters * multiplier
    return letters

def getS(sentence, length, words):
    sentences = 0
    multiplier = 100 / words
    for i in range(length):
        if ord(sentence[i]) == 33 or ord(sentence[i]) == 46 or ord(sentence[i]) == 63:
            sentences = sentences + 1
    print(str(sentences) + " Sentence(s)")
    sentences = sentences * multiplier
    return sentences
    
main()