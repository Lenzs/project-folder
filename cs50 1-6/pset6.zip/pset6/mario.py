from cs50 import get_int

index = 0
block = 1
while index < 1 or index > 8:
    index = get_int("Height: ")

for x in range(index):
    space = index - 1
    
    for x in range(space):
        print(" ", end="")
    print("#" * block, end="")
    
    print("  ", end="")
    
    print("#" * block, end="")
    for x in range(space):
        print("", end="")
    
    print("")
    index = index - 1
    block = block + 1

