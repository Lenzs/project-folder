#include <stdio.h>
#include <cs50.h>

int getNumLength(long n);

bool checkValidity(long n);


int main(void)
{
    long card;
    int cardLength;
    bool isValid;
    card = get_long (" Number: ");
    cardLength = getNumLength(card);
    isValid = checkValidity(card);
    if(isValid)
    {
        if(cardLength==15 && ((card >= 34e13 && card < 35e13) || (card >= 37e13 && card < 38e13)))
        {
            printf("AMEX\n");
        }
        else if(cardLength==16 && card >= 51e14 && card < 56e14)
        {
            printf("MASTERCARD\n");
        }
        else if((cardLength==13 && card >= 4e12 && card < 5e12) || (cardLength==16 && card >= 4e15 && card < 5e15))
        {
            printf("VISA\n");
        }
        else 
        {
            printf("INVALID\n");
        }
    }
    else
    {
        printf("INVALID\n");
    }

}

int getNumLength(long n)
{
    int length;
    for(int i = 0; n!=0; i++)
    {
        n = n/10;
        length = i + 1;
    }
    return length;
}

bool checkValidity(long n)
{
    int num1;
    int sum1 = 0;
    int num2;
    int sum2 = 0;
    int sumFinal;
    for(int i = 0; n!=0; i++)
    {
        if(i%2==0)
        {
            num1 = n%10;
            sum1 = sum1 + num1;
        }
        else
        {
            num2 = n%10;
            num2 = num2*2;
            sum2 = sum2 + num2/10 + num2%10;
        }
        sumFinal = sum1 + sum2;
        n = n/10;
    }
    if(sumFinal%10==0)
    {
        return(true);
    }
    else
    {
        return(false);
    }
}



