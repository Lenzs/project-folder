#include <stdio.h>
#include <cs50.h>

int main(void)
{
    int n;
    do
    {
    n = get_int ("Height: ");
    }
    while (n < 1 || n > 8);
    
    for(int i = 0; i<n; i++)
    {
        int space = n - i - 1;
        for(int x = 0; x<space; x++)
        {
            printf(" ");
        }
        for(int y = 0; y <= i; y++)
        {
            printf("#");
        }
        printf("  ");
        for(int z = 0; z <= i; z++)
        {
            printf("#");
        }
        printf("\n");
    }
}

