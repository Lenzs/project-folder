#include <stdio.h>
#include <cs50.h>
#include <string.h>
#include <math.h>

float getL(char *sentence, int length, float words);
float getS(char *sentence, int length, float words);

int main(void)
{
    float averageL;
    float averageS; 
    int words = 1;
    float index;
    string text = get_string("Text: ");
    int length = strlen(text);
    char *sentence = text;
    
    for (int i = 0; i < length; i++)
    {
        if (text[i] == 32)
        {
            words++;
        }
    }
    averageL = getL(sentence, length, words);
    printf("%i Word(s)\n", words);
    averageS = getS(sentence, length, words);
    
    index = (0.0588 * averageL - 0.296 * averageS - 15.8);
    if (index < 16.5 && index >= 0.5)
    {
        index = round(index);
        printf("Grade %.0f\n", index);
    }
    else if (index > 16.5)
    {
        index = round(index);
        printf("Grade 16+\n");
    }
    else if (index < 0.5)
    {
        printf("Before Grade 1\n");
    }
}

float getL(char *sentence, int length, float words)
{
    float letters = 0;
    float multiplier = 100 / words;
    for (int i = 0; i < length; i++)
    {
        if ((sentence[i] < 123 && sentence[i] > 96) || (sentence[i] < 91 && sentence[i] > 64))
        {
            letters++;
        }
    }
    printf("%.0f Letter(s)\n", letters);
    letters = letters * multiplier;
    return letters;
}

float getS(char *sentence, int length, float words)
{
    float sentences = 0;
    float multiplier = 100 / words;
    for (int i = 0; i < length; i++)
    {
        if ((sentence[i] == 33) || (sentence[i] == 46) || (sentence[i] == 63))
        {
            sentences++;
        }
    }
    printf("%.0f Sentence(s)\n", sentences);
    sentences = sentences * multiplier;
    return sentences;
}
