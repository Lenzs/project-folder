#include <stdio.h>
#include <cs50.h>
#include <string.h>
#include<stdlib.h> 
#include <ctype.h>

bool checkValidity(string key, int keyNum);

int main(int keyNum, string key[])
{
    if (keyNum != 2)
    {
        printf("Usage: ./substitution key\n");
        return 1;
    }

    if (checkValidity(key[1], keyNum))
    {
        printf("Usage: ./substitution key\n");
        return 1;
    }

    string plainText = get_string("plaintext: ");
    int length = strlen(plainText);
    string cipherKey = key[1];
    bool lowercase[length];
    bool spaceLog[length];
    int numberLog[length];
    
    for (int i = 0; i < length; i++)
    {
        cipherKey[i] = toupper(cipherKey[i]);
        lowercase[i] = false;
        spaceLog[i] = false;
        numberLog[i] = 0;
    }
    for (int i = 0; i < length; i++)
    {
        if (islower(plainText[i]))
        {
            lowercase[i] = true;
        }
        if (plainText[i] == 32)
        {
            spaceLog[i] = true;
        }
        if (isdigit(plainText[i]))
        {
            numberLog[i] = plainText[i];
        } 
    }
    for (int i = 0; i < length; i++)
    {
        int alphaLog = toupper(plainText[i]) - 65;
        if (!spaceLog[i] && !isdigit(plainText[i]))
        {
            plainText[i] = cipherKey[alphaLog];
        }
        else if (!spaceLog[i] && numberLog[i] == 0)
        {
            plainText[i] = 32;
        }
        else if (numberLog[i] != 0 && !spaceLog[i])
        {
            plainText[i] = numberLog[i];
        }
    }
    
    for (int i = 0; i < length; i++)
    {
        if (lowercase[i])
        {
            plainText[i] = tolower(plainText[i]);
        }
        else 
        {
            plainText[i] = toupper(plainText[i]);
        }
    }
    
    string cipherText = plainText;
    printf("ciphertext: %s\n", cipherText);
    return 0;
}

bool checkValidity(string key, int keyNum)
{
    int seen[26] = {0};
    
    for (int i = 0; i < strlen(key); i++)
    {
        int alphaLog = toupper(key[i]) - 65;
        
        if (!isalpha(key[i]))
        {
            return true;
        }
        else
        {
            seen[alphaLog]++;
        }
        if (seen[alphaLog] > 1)
        {
            return true;
        }
        
        if (strlen(key) != 26)
        {
            return true;
        }
        
        if (keyNum == 0)
        {
            return true;
        }
    }
    
    return false;
}


